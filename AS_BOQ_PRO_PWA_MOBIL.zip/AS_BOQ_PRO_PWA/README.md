# A.S BOQ PRO V1

Web tabanlı keşif, maliyet, BOQ ve hakediş uygulamasının ilk çalışan sürümüdür.

## Özellikler

- Proje oluşturma ve proje seçimi
- Poz kütüphanesi
- Malzeme + işçilik birim fiyatı
- BOQ satırları
- Sözleşme miktarı ve toplam tutar
- Hakediş dönemleri
- Önceki, bu dönem, kümülatif ve kalan miktarlar
- Dashboard özetleri
- SQLite veritabanı
- Türkçe ve TL formatına uygun arayüz

## Kurulum

Python 3.11 veya üzeri önerilir.

Windows için en kolay yöntem:

```bat
kurulum_ve_calistir.bat
```

Bu dosya kurulumu yapar, sunucuyu başlatır ve tarayıcıyı otomatik açar.
Siyah komut penceresi program açıkken kapatılmamalıdır.

Manuel:

```bash
python -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
uvicorn app.main:app --reload
```

Tarayıcı:

http://127.0.0.1:8000

## Sonraki sürüm

- Mevcut Excel dosyasından poz aktarımı
- Excel ve PDF çıktı
- Malzeme/işçilik analiz detayları
- Satın alma ve taşeron modülleri
- Kullanıcı yetkilendirme
