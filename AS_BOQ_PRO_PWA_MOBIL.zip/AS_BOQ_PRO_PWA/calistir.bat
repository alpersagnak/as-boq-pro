@echo off
setlocal
cd /d "%~dp0"
title A.S BOQ PRO

if not exist ".venv\Scripts\python.exe" (
    echo Ilk kurulum yapilmamis.
    echo kurulum_ve_calistir.bat dosyasini calistirin.
    pause
    exit /b 1
)

echo A.S BOQ PRO aciliyor...
echo Tarayici adresi: http://127.0.0.1:8000
echo Bu pencere program acikken kapanmamalidir.

start "" cmd /c "timeout /t 3 /nobreak >nul && start http://127.0.0.1:8000"
".venv\Scripts\python.exe" -m uvicorn app.main:app --host 127.0.0.1 --port 8000

pause
endlocal
