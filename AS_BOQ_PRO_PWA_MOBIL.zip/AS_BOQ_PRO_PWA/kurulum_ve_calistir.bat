@echo off
setlocal
cd /d "%~dp0"
title A.S BOQ PRO

echo ==========================================
echo       A.S BOQ PRO BASLATILIYOR
echo ==========================================
echo.

where python >nul 2>nul
if errorlevel 1 (
    echo HATA: Python bulunamadi.
    echo Python 3.11 veya 3.12 kurmaniz gerekiyor.
    echo Kurulumda "Add Python to PATH" kutusunu isaretleyin.
    echo.
    pause
    exit /b 1
)

if not exist ".venv\Scripts\python.exe" (
    echo Sanal ortam olusturuluyor...
    python -m venv .venv
    if errorlevel 1 goto error
)

echo Kutuphaneler kontrol ediliyor...
".venv\Scripts\python.exe" -m pip install --upgrade pip
if errorlevel 1 goto error

".venv\Scripts\python.exe" -m pip install -r requirements.txt
if errorlevel 1 goto error

echo.
echo Program aciliyor...
echo Tarayici adresi: http://127.0.0.1:8000
echo Bu siyah pencere program acikken kapanmamalidir.
echo.

start "" cmd /c "timeout /t 4 /nobreak >nul && start http://127.0.0.1:8000"
".venv\Scripts\python.exe" -m uvicorn app.main:app --host 127.0.0.1 --port 8000

goto end

:error
echo.
echo KURULUM VEYA BASLATMA HATASI OLUSTU.
echo Yukaridaki hata mesajinin ekran goruntusunu paylasin.
pause

:end
endlocal
