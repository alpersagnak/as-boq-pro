@echo off
setlocal
cd /d "%~dp0"
title A.S BOQ PRO Kurulum

where python >nul 2>nul
if errorlevel 1 (
    echo HATA: Python bulunamadi.
    echo Python 3.11 veya 3.12 kurun ve "Add Python to PATH" secenegini isaretleyin.
    pause
    exit /b 1
)

python -m venv .venv
if errorlevel 1 goto error

".venv\Scripts\python.exe" -m pip install --upgrade pip
if errorlevel 1 goto error

".venv\Scripts\python.exe" -m pip install -r requirements.txt
if errorlevel 1 goto error

echo.
echo Kurulum tamamlandi.
echo Simdi calistir.bat dosyasini acin.
pause
exit /b 0

:error
echo.
echo Kurulum hatasi olustu.
pause
endlocal
