@echo off
cd /d "%~dp0"
echo A.S BOQ PRO SISTEM KONTROLU
echo ==========================
echo.
echo Klasor:
cd
echo.
echo Python:
python --version
echo.
echo Sanal ortam:
if exist ".venv\Scripts\python.exe" (
  ".venv\Scripts\python.exe" --version
) else (
  echo Sanal ortam bulunamadi.
)
echo.
echo Dosyalar:
dir app
echo.
pause
