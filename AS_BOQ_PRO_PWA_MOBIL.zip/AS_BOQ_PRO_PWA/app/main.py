from datetime import date
from pathlib import Path
from fastapi import Depends, FastAPI, Form, Request
from fastapi.responses import RedirectResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from sqlalchemy import func
from sqlalchemy.orm import Session, joinedload

from .database import Base, SessionLocal, engine
from .models import BoqItem, Poz, ProgressLine, ProgressPeriod, Project

Base.metadata.create_all(bind=engine)

app = FastAPI(title="A.S BOQ PRO", version="1.0.0")

ROOT = Path(__file__).resolve().parent
app.mount("/static", StaticFiles(directory=ROOT / "static"), name="static")
templates = Jinja2Templates(directory=ROOT / "templates")


def money(value: float) -> str:
    value = value or 0
    return f"{value:,.2f}".replace(",", "X").replace(".", ",").replace("X", ".")


templates.env.filters["money"] = money


def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


@app.get("/")
def dashboard(request: Request, project_id: int | None = None, db: Session = Depends(get_db)):
    projects = db.query(Project).order_by(Project.name).all()
    selected = None
    boq_total = progress_total = remaining_total = 0.0

    if project_id:
        selected = db.query(Project).filter(Project.id == project_id).first()
    elif projects:
        selected = projects[0]

    if selected:
        items = (
            db.query(BoqItem)
            .options(joinedload(BoqItem.poz))
            .filter(BoqItem.project_id == selected.id)
            .all()
        )
        boq_total = sum(item.amount for item in items)
        lines = (
            db.query(ProgressLine)
            .join(ProgressPeriod)
            .join(BoqItem)
            .options(joinedload(ProgressLine.boq_item).joinedload(BoqItem.poz))
            .filter(ProgressPeriod.project_id == selected.id)
            .all()
        )
        progress_total = sum(line.current_quantity * line.boq_item.poz.unit_price for line in lines)
        remaining_total = max(boq_total - progress_total, 0)

    return templates.TemplateResponse("dashboard.html", {
        "request": request,
        "projects": projects,
        "selected": selected,
        "boq_total": boq_total,
        "progress_total": progress_total,
        "remaining_total": remaining_total,
    })


@app.get("/projects")
def projects_page(request: Request, db: Session = Depends(get_db)):
    projects = db.query(Project).order_by(Project.id.desc()).all()
    return templates.TemplateResponse("projects.html", {"request": request, "projects": projects})


@app.post("/projects")
def create_project(
    code: str = Form(...),
    name: str = Form(...),
    employer: str = Form(""),
    contractor: str = Form(""),
    currency: str = Form("TRY"),
    db: Session = Depends(get_db),
):
    project = Project(
        code=code.strip(),
        name=name.strip(),
        employer=employer.strip(),
        contractor=contractor.strip(),
        currency=currency,
    )
    db.add(project)
    db.commit()
    return RedirectResponse("/projects", status_code=303)


@app.get("/pozlar")
def pozlar_page(request: Request, db: Session = Depends(get_db)):
    pozlar = db.query(Poz).order_by(Poz.poz_no).all()
    return templates.TemplateResponse("pozlar.html", {"request": request, "pozlar": pozlar})


@app.post("/pozlar")
def create_poz(
    poz_no: str = Form(...),
    description: str = Form(...),
    unit: str = Form(...),
    category: str = Form(""),
    material_price: float = Form(0),
    labor_price: float = Form(0),
    db: Session = Depends(get_db),
):
    poz = Poz(
        poz_no=poz_no.strip(),
        description=description.strip(),
        unit=unit.strip(),
        category=category.strip(),
        material_price=material_price,
        labor_price=labor_price,
    )
    db.add(poz)
    db.commit()
    return RedirectResponse("/pozlar", status_code=303)


@app.get("/boq")
def boq_page(request: Request, project_id: int | None = None, db: Session = Depends(get_db)):
    projects = db.query(Project).order_by(Project.name).all()
    pozlar = db.query(Poz).order_by(Poz.poz_no).all()
    selected = db.query(Project).filter(Project.id == project_id).first() if project_id else (projects[0] if projects else None)
    items = []
    if selected:
        items = (
            db.query(BoqItem)
            .options(joinedload(BoqItem.poz))
            .filter(BoqItem.project_id == selected.id)
            .order_by(BoqItem.id)
            .all()
        )
    return templates.TemplateResponse("boq.html", {
        "request": request,
        "projects": projects,
        "pozlar": pozlar,
        "selected": selected,
        "items": items,
        "total": sum(x.amount for x in items),
    })


@app.post("/boq")
def add_boq_item(
    project_id: int = Form(...),
    poz_id: int = Form(...),
    quantity: float = Form(...),
    db: Session = Depends(get_db),
):
    existing = db.query(BoqItem).filter(
        BoqItem.project_id == project_id,
        BoqItem.poz_id == poz_id,
    ).first()
    if existing:
        existing.quantity += quantity
    else:
        db.add(BoqItem(project_id=project_id, poz_id=poz_id, quantity=quantity))
    db.commit()
    return RedirectResponse(f"/boq?project_id={project_id}", status_code=303)


@app.get("/hakedis")
def progress_page(request: Request, project_id: int | None = None, period_id: int | None = None, db: Session = Depends(get_db)):
    projects = db.query(Project).order_by(Project.name).all()
    selected = db.query(Project).filter(Project.id == project_id).first() if project_id else (projects[0] if projects else None)
    periods = []
    active_period = None
    items = []
    previous_map = {}
    current_map = {}

    if selected:
        periods = db.query(ProgressPeriod).filter(ProgressPeriod.project_id == selected.id).order_by(ProgressPeriod.number).all()
        active_period = db.query(ProgressPeriod).filter(ProgressPeriod.id == period_id).first() if period_id else (periods[-1] if periods else None)
        items = (
            db.query(BoqItem)
            .options(joinedload(BoqItem.poz))
            .filter(BoqItem.project_id == selected.id)
            .order_by(BoqItem.id)
            .all()
        )
        for item in items:
            previous = (
                db.query(func.coalesce(func.sum(ProgressLine.current_quantity), 0))
                .join(ProgressPeriod)
                .filter(
                    ProgressLine.boq_item_id == item.id,
                    ProgressPeriod.project_id == selected.id,
                    ProgressPeriod.number < (active_period.number if active_period else 10**9),
                )
                .scalar()
            )
            previous_map[item.id] = float(previous or 0)
        if active_period:
            lines = db.query(ProgressLine).filter(ProgressLine.period_id == active_period.id).all()
            current_map = {line.boq_item_id: line.current_quantity for line in lines}

    return templates.TemplateResponse("hakedis.html", {
        "request": request,
        "projects": projects,
        "selected": selected,
        "periods": periods,
        "active_period": active_period,
        "items": items,
        "previous_map": previous_map,
        "current_map": current_map,
        "today": date.today().isoformat(),
    })


@app.post("/hakedis/period")
def create_period(
    project_id: int = Form(...),
    number: int = Form(...),
    period_date: date = Form(...),
    description: str = Form(""),
    db: Session = Depends(get_db),
):
    period = ProgressPeriod(project_id=project_id, number=number, period_date=period_date, description=description)
    db.add(period)
    db.commit()
    db.refresh(period)
    return RedirectResponse(f"/hakedis?project_id={project_id}&period_id={period.id}", status_code=303)


@app.post("/hakedis/save")
async def save_progress(request: Request, db: Session = Depends(get_db)):
    form = await request.form()
    period_id = int(form["period_id"])
    period = db.query(ProgressPeriod).filter(ProgressPeriod.id == period_id).first()
    if not period:
        return RedirectResponse("/hakedis", status_code=303)

    items = db.query(BoqItem).filter(BoqItem.project_id == period.project_id).all()
    for item in items:
        key = f"qty_{item.id}"
        raw = str(form.get(key, "0")).replace(",", ".").strip()
        try:
            qty = float(raw or 0)
        except ValueError:
            qty = 0
        line = db.query(ProgressLine).filter(
            ProgressLine.period_id == period_id,
            ProgressLine.boq_item_id == item.id,
        ).first()
        if line:
            line.current_quantity = qty
        else:
            db.add(ProgressLine(period_id=period_id, boq_item_id=item.id, current_quantity=qty))
    db.commit()
    return RedirectResponse(f"/hakedis?project_id={period.project_id}&period_id={period.id}", status_code=303)
