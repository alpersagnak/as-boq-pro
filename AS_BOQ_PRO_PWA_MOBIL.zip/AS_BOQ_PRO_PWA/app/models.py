from datetime import date
from sqlalchemy import Date, Float, ForeignKey, Integer, String
from sqlalchemy.orm import Mapped, mapped_column, relationship
from .database import Base


class Project(Base):
    __tablename__ = "projects"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    code: Mapped[str] = mapped_column(String(30), unique=True, index=True)
    name: Mapped[str] = mapped_column(String(200))
    employer: Mapped[str] = mapped_column(String(200), default="")
    contractor: Mapped[str] = mapped_column(String(200), default="")
    currency: Mapped[str] = mapped_column(String(10), default="TRY")

    boq_items = relationship("BoqItem", back_populates="project", cascade="all, delete-orphan")
    progress_periods = relationship("ProgressPeriod", back_populates="project", cascade="all, delete-orphan")


class Poz(Base):
    __tablename__ = "pozlar"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    poz_no: Mapped[str] = mapped_column(String(60), unique=True, index=True)
    description: Mapped[str] = mapped_column(String(300))
    unit: Mapped[str] = mapped_column(String(20))
    category: Mapped[str] = mapped_column(String(100), default="")
    material_price: Mapped[float] = mapped_column(Float, default=0)
    labor_price: Mapped[float] = mapped_column(Float, default=0)

    boq_items = relationship("BoqItem", back_populates="poz")

    @property
    def unit_price(self) -> float:
        return (self.material_price or 0) + (self.labor_price or 0)


class BoqItem(Base):
    __tablename__ = "boq_items"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    project_id: Mapped[int] = mapped_column(ForeignKey("projects.id"))
    poz_id: Mapped[int] = mapped_column(ForeignKey("pozlar.id"))
    quantity: Mapped[float] = mapped_column(Float, default=0)

    project = relationship("Project", back_populates="boq_items")
    poz = relationship("Poz", back_populates="boq_items")
    progress_lines = relationship("ProgressLine", back_populates="boq_item", cascade="all, delete-orphan")

    @property
    def amount(self) -> float:
        return self.quantity * self.poz.unit_price


class ProgressPeriod(Base):
    __tablename__ = "progress_periods"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    project_id: Mapped[int] = mapped_column(ForeignKey("projects.id"))
    number: Mapped[int] = mapped_column(Integer)
    period_date: Mapped[date] = mapped_column(Date, default=date.today)
    description: Mapped[str] = mapped_column(String(200), default="")

    project = relationship("Project", back_populates="progress_periods")
    lines = relationship("ProgressLine", back_populates="period", cascade="all, delete-orphan")


class ProgressLine(Base):
    __tablename__ = "progress_lines"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    period_id: Mapped[int] = mapped_column(ForeignKey("progress_periods.id"))
    boq_item_id: Mapped[int] = mapped_column(ForeignKey("boq_items.id"))
    current_quantity: Mapped[float] = mapped_column(Float, default=0)

    period = relationship("ProgressPeriod", back_populates="lines")
    boq_item = relationship("BoqItem", back_populates="progress_lines")
