# A.S BOQ PRO Mobil Kurulum

Bu paket PWA olarak hazırlanmıştır.

## Buluta yayınlama

1. Proje dosyalarını bir GitHub deposuna yükleyin.
2. Render veya benzeri bir Python/Docker hosting hizmetinde yeni Web Service oluşturun.
3. GitHub deposunu bağlayın.
4. Dockerfile otomatik algılanır.
5. Yayın tamamlandığında verilen HTTPS adresini iPhone Safari'de açın.

## iPhone ana ekrana ekleme

1. Safari'de uygulama adresini açın.
2. Paylaş simgesine dokunun.
3. “Ana Ekrana Ekle” seçeneğini seçin.
4. Uygulama, tam ekran çalışır.

## Önemli

SQLite veritabanı ücretsiz geçici hostinglerde kalıcı olmayabilir. Gerçek kullanımda PostgreSQL ve kalıcı disk gerekir.
